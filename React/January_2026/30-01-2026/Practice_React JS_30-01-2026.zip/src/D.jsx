import React from 'react'

const D = ({ value }) => {
  return (
    <div>
      <h2>NYB Infotech - {value}</h2>
    </div>
  )
}

export default D
