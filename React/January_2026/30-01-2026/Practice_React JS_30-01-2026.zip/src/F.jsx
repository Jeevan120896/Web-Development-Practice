import React from 'react'

const F = ({ value }) => {
  return (
    <div>
      <h2>Hello {value}</h2>
    </div>
  )
}

export default F
