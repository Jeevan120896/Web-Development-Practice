import { useState } from 'react'
import Parent from './Parent'

function App() {
  

  return (
    <Parent/>
  )
}

export default App
