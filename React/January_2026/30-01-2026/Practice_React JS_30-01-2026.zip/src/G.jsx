import React from 'react'

const G = ({ value }) => {
  return (
    <div>
      <p>React - {value}</p>
    </div>
  )
}

export default G
