import React from 'react'

const E = ({ value }) => {
  return (
    <div>
      <h1>Welcome to {value}</h1>
    </div>
  )
}

export default E
