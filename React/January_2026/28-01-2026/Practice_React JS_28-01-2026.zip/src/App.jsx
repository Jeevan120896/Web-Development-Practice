import Parent from './Parent'

function App() {
  return (
    <>
      <Parent />
   
     
    </>
  )
}

export default App
